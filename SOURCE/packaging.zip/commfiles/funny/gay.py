from bottype import Context
import botlib
import random

def main(ctx: Context):
    # srch = ctx.args[0] if len(ctx.args) > 0 else ctx.user
    # random.seed(srch)
    # g = random.randint(0, 10000) / 100
    # botlib.followup(ctx.user, f"{srch} is {g}% gay (based off of seeded random number generator)")
    # I got banned on the minecraft server for using this command
    botlib.followup(ctx.user, "This command is disabled to prevent issues")
    
