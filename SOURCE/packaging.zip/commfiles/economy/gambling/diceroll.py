from bottype import Context
import botlib
import random

def main(ctx: Context):
    if not ctx.args:
        botlib.followup(ctx.user, f"Please specify an amount.")
        return

    try:
        amount = int(ctx.args[0])
    except (ValueError, TypeError):
        botlib.followup(ctx.user, f"Invalid integer")
        return

    if amount <= 0:
        botlib.followup(ctx.user, f"Amount must be greater than zero.")
        return

    if botlib.balances[ctx.user] < amount:
        botlib.followup(ctx.user, f"Not enough balance to complete the transaction.")
        return
    
    roll = random.randint(0, 6)
    if roll == 6:
        gain = 6*amount
    else:
        gain = 0

    if gain > 9:
        botlib.setbal(ctx.user, botlib.balances[ctx.user] + amount)
        botlib.followup(ctx.user, f"You won! You gained {amount*6} balances and rolled a 6!")
    else:
        botlib.setbal(ctx.user, botlib.balances[ctx.user] - amount)
        botlib.followup(ctx.user, f"good job; You lost {amount} balance and rolled a {roll}")