from botlib import BotCommandExecutionError
from bottype import Context
import botlib
import random

def main(ctx: Context):
    if len(ctx.args) < 1:
        botlib.followup(ctx.user, "Usage: !randutil <d<number>|integer <number>-<number>>|float <number>-<number> <step>|choices <list separated by ,>")
        return
    if ctx.args[0].startswith("d"):
        dice_sides = ctx.args[0].replace("d", "")
        try: 
            dice_sides = int(dice_sides)
        except:
            raise botlib.BotCommandExecutionError("Not an integer")
        rolled = random.randint(1, dice_sides)
        botlib.followup(ctx.user, f"You rolled a {rolled}!")
    elif ctx.args[0] == "integer":
        range = ctx.args[1].split("-")
        try: 
            range = [int(range[0]), int(range[1])]
        except:
            raise botlib.BotCommandExecutionError("One or two values in the range is not an integer")
        rolled = random.randint(range[0], range[1])
        botlib.followup(ctx.user, f"You got {rolled}!")
    elif ctx.args[0] == "float":
        range = ctx.args[1].split("-")
        step = ctx.args[2]
        try: 
            range = [float(range[0]), float(range[1])]
            step = float(step)
        except:
            raise botlib.BotCommandExecutionError("One or two values in the range is not an integer")
        rolled = random.randrange(range[0], range[1], step)
        botlib.followup(ctx.user, f"You got {rolled}!")
    elif ctx.args[0] == "choices":
        # Choose between a list of Floats (to prevent bad words)
        choices = ctx.args[1].split(",")
        for ch in choices:
            try: 
                float(ch)
            except: 
                raise BotCommandExecutionError("All values must be a float or integer")
        rolled = random.choice(choices)
        botlib.followup(ctx.user, f"Out of all the options, you got {rolled}!")
    else:
        botlib.followup(ctx.user, "Usage: !randutil <d<number>|integer <number>-<number>>|float <number>-<number> <step>|choices <list separated by ,>")

        
