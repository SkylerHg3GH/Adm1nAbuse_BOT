Get-ChildItem . -Recurse -Directory -Filter __pycache__ | Remove-Item -Recurse -Force
Get-ChildItem . -Recurse -File -Include *.pyc,*.pyo,*.pyd,'*$py.class' | Remove-Item -Force
Get-ChildItem . -Recurse -File | Where-Object Name -in @(
    "config.yml","bans.yml","pdata.json","bal.json","queue.txt","perms.yml"
) | Remove-Item -Force